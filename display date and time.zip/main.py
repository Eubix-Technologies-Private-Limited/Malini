from machine import Pin
import utime
import time

# Initialize the LCD using the gpio_lcd library
from gpio_lcd import GpioLcd

# Create the LCD object using the gpio_lcd library
lcd = GpioLcd(rs_pin=Pin(15),
              enable_pin=Pin(14),
              d4_pin=Pin(9),
              d5_pin=Pin(8),
              d6_pin=Pin(7),
              d7_pin=Pin(6),
              num_lines=2, num_columns=16)

# Create a custom character (happy face)
happy_face = bytearray([
  0x00,
  0x00,
  0x11,
  0x1B,
  0x1F,
  0x15,
  0x11,
  0x11

])
lcd.custom_char(0, happy_face)

# Initialize the LCD display
lcd.clear()

# Get user input (name)
name = "Malini"

# Set the current time manually (24-hour format)
current_time = time.mktime((2024, 8, 20, 11, 40, 40, 0, 0, 0))  # Year, Month, Day, Hour, Minute, Second, Weekday, Yearday, DST

# Function to format the date as YYYY-MM-DD
def format_date(t):
    return "{:04}-{:02}-{:02}".format(t[0], t[1], t[2])

# Function to format the time as HH:MM:SS
def format_time(t):
    return "{:02}:{:02}:{:02}".format(t[3], t[4], t[5])

# Display the name with a special character and the current date/time on the LCD
while True:
    # Get the current time in tuple form
    t = time.localtime(current_time)
    
    # Format the date and time strings for display
    date_str = format_date(t)
    time_str = format_time(t)
    
    # Clear the display
    lcd.clear()
    
    # Display the user's name with a special character on the first line
    lcd.move_to(0, 0)
    lcd.putstr(name)
    lcd.putchar(chr(0))  # Display the happy face next to the name
    lcd.putstr(time_str)
    # Display the current date and time on the second line
    lcd.move_to(0, 1)
    lcd.putstr(date_str)  # Display date and time (HH:MM:SS)

    # Sleep for one second
    utime.sleep(1)
    
    # Increment the current_time by one second to simulate a clock
    current_time += 1

